#!/usr/bin/perl
#Beautify "REFAL ERROR" message

while (<STDIN>) {
    # NL --> CR NL
    s/\12/\15\12/;
    s/\&/\&amp\;/g;
    s/ /\&nbsp\;/g;
    s/\</\&lt\;/g;
    s/\>/\&gt\;/g;
    s/\"/\&quot\;/g;
    s/\[Yn\]/\[Yn\]\<BR\>/g;
    s/^REFAL\&nbsp;ERROR/\<font size\=\"\+1\" color\=\"\#aa0000\"\>REFAL ERROR\<\/font\>/;
    print "$_<BR>";
}
